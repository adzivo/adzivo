"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { nav, bookingHref } from "@/config/site";
import { Logo } from "./Logo";
import { ButtonLink } from "./Button";

export function Header() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-line bg-ink/80 backdrop-blur-md">
      <div className="container-x flex h-16 items-center justify-between">
        <Logo />
        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
          {nav.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link key={item.href} href={item.href} aria-current={active ? "page" : undefined}
                className={`rounded-md px-3 py-2 text-sm font-medium transition ${active ? "text-white" : "text-mute hover:text-white"}`}>
                {item.label}
              </Link>
            );
          })}
          <ButtonLink href={bookingHref} className="ml-3 !py-2.5">Book a Strategy Call</ButtonLink>
        </nav>
        <button type="button" className="rounded-md border border-line p-2.5 lg:hidden" aria-expanded={open} aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen((o) => !o)}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </div>
      <div id="mobile-menu" hidden={!open} className="fixed inset-x-0 top-16 bottom-0 overflow-y-auto bg-ink px-5 pb-10 pt-4 lg:hidden">
        <nav aria-label="Mobile" className="flex flex-col">
          {nav.map((item) => (
            <Link key={item.href} href={item.href} className="border-b border-line py-4 text-lg font-medium">{item.label}</Link>
          ))}
        </nav>
        <ButtonLink href={bookingHref} className="mt-8 w-full">Book a Strategy Call</ButtonLink>
      </div>
    </header>
  );
}
