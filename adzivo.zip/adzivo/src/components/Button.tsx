import Link from "next/link";
import type { ReactNode } from "react";

type Props = { href: string; variant?: "primary" | "secondary" | "ghost"; children: ReactNode; className?: string };

export function ButtonLink({ href, variant = "primary", children, className = "" }: Props) {
  const cls = `btn btn-${variant} ${className}`.trim();
  if (/^https?:\/\//.test(href)) {
    return (
      <a href={href} className={cls} target="_blank" rel="noopener noreferrer">
        {children}
        <span className="sr-only"> (opens in a new tab)</span>
      </a>
    );
  }
  return <Link href={href} className={cls}>{children}</Link>;
}
