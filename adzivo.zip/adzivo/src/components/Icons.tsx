import type { Service } from "@/content/data";

const paths: Record<Service["icon"], string> = {
  target: "M12 3a9 9 0 1 0 9 9M12 7a5 5 0 1 0 5 5M12 11a1 1 0 1 0 1 1M21 3l-8 8M17 3h4v4",
  social: "M4 5h16v11H9l-5 4V5zM8 9h8M8 12h5",
  flask: "M9 3h6M10 3v6L5 19a1 1 0 0 0 .9 1.5h12.2A1 1 0 0 0 19 19l-5-10V3M8 15h8",
  users: "M16 20v-1.5a3.5 3.5 0 0 0-3.5-3.5h-5A3.5 3.5 0 0 0 4 18.5V20M10 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM20 20v-1.5a3.5 3.5 0 0 0-2.5-3.3M15.5 4.2a3.5 3.5 0 0 1 0 6.6",
  funnel: "M3 4h18l-7 8.5V19l-4 2v-8.5L3 4z",
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2",
};

export function ServiceIcon({ name }: { name: Service["icon"] }) {
  return (
    <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-line bg-gradient-to-br from-electric/20 to-violet/20 text-[#a9baff]">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d={paths[name]} />
      </svg>
    </span>
  );
}

export function Check() {
  return (
    <svg className="mt-1 h-4 w-4 flex-none text-[#8fa6ff]" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m4 10.5 4 4 8-9" />
    </svg>
  );
}
