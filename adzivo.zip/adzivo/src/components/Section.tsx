import type { ReactNode } from "react";

export function Section({ id, eyebrow, title, intro, children, className = "" }: {
  id?: string; eyebrow?: string; title?: string; intro?: string; children?: ReactNode; className?: string;
}) {
  return (
    <section id={id} className={`py-16 sm:py-24 ${className}`}>
      <div className="container-x">
        {(eyebrow || title) && (
          <div className="mb-10 max-w-2xl sm:mb-14">
            {eyebrow && <p className="eyebrow mb-3">{eyebrow}</p>}
            {title && <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">{title}</h2>}
            {intro && <p className="mt-4 text-lg text-mute">{intro}</p>}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}

export function PageHero({ eyebrow, title, intro }: { eyebrow: string; title: string; intro: string }) {
  return (
    <header className="hero-glow relative border-b border-line pb-14 pt-32 sm:pb-20 sm:pt-40">
      <div className="container-x max-w-4xl">
        <p className="eyebrow mb-4">{eyebrow}</p>
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">{title}</h1>
        <p className="mt-5 max-w-2xl text-lg text-mute">{intro}</p>
      </div>
    </header>
  );
}
