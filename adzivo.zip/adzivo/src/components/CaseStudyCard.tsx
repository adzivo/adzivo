import type { CaseStudy } from "@/content/data";

export function CaseStudyCard({ study }: { study: CaseStudy }) {
  return (
    <article className="card flex flex-col">
      <p className="mb-4 inline-flex w-fit rounded-md border border-amber-400/60 bg-amber-400/10 px-2.5 py-1 text-xs font-bold uppercase tracking-wider text-amber-200">
        Demo Content — Replace Before Publishing
      </p>
      <h3 className="text-lg font-semibold">{study.client}</h3>
      <p className="text-sm text-[#8fa6ff]">{study.industry} · {study.timeframe}</p>
      <dl className="mt-5 space-y-4 text-sm">
        <div><dt className="font-semibold">Challenge</dt><dd className="mt-1 text-mute">{study.challenge}</dd></div>
        <div><dt className="font-semibold">Strategy</dt><dd className="mt-1 text-mute">{study.strategy}</dd></div>
        <div>
          <dt className="font-semibold">Results</dt>
          <dd><ul className="mt-1 list-disc space-y-1 pl-5 text-mute">{study.results.map((r, i) => <li key={i}>{r}</li>)}</ul></dd>
        </div>
      </dl>
    </article>
  );
}
