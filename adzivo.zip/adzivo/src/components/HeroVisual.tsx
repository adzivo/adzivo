/**
 * Decorative, illustrative visual only. It intentionally contains NO numeric data
 * so it can't be mistaken for real campaign results.
 */
const heights = [38, 52, 44, 66, 58, 78, 70];

export function HeroVisual() {
  return (
    <div className="relative mx-auto w-full max-w-xl" role="img" aria-label="Illustrative concept of an ad campaign flowing from ads to creative tests, leads and reporting. Not real data.">
      <div className="absolute -inset-6 rounded-[2rem] bg-gradient-to-br from-electric/25 to-violet/25 blur-3xl" aria-hidden="true" />
      <div className="relative rounded-2xl border border-line bg-navy/90 p-5 shadow-2xl" aria-hidden="true">
        <div className="mb-5 flex items-center justify-between">
          <div className="flex gap-1.5"><i className="h-2.5 w-2.5 rounded-full bg-white/20" /><i className="h-2.5 w-2.5 rounded-full bg-white/20" /><i className="h-2.5 w-2.5 rounded-full bg-white/20" /></div>
          <span className="text-[11px] uppercase tracking-widest text-mute">Campaign overview</span>
        </div>

        <div className="relative mb-6">
          <div className="absolute left-0 right-0 top-[18px] h-px bg-line" />
          <div className="absolute top-[14px] h-2 w-2 -translate-x-1/2 animate-travel rounded-full bg-electric shadow-[0_0_12px_#3b6bff]" />
          <ol className="relative grid grid-cols-4 gap-2 text-center text-[11px] text-mute">
            {["Ads", "Creative tests", "Leads", "Reporting"].map((s, i) => (
              <li key={s} className="flex flex-col items-center gap-2">
                <span className={`flex h-9 w-9 items-center justify-center rounded-full border border-line bg-panel text-xs font-semibold ${i === 2 ? "text-white" : "text-[#a9baff]"}`}>{i + 1}</span>
                {s}
              </li>
            ))}
          </ol>
        </div>

        <div className="flex h-36 items-end gap-2 rounded-xl border border-line bg-panel/60 p-4">
          {heights.map((h, i) => (
            <div key={i} className="flex-1 origin-bottom animate-bar rounded-t bg-gradient-to-t from-electric/70 to-violet/80"
              style={{ height: `${h}%`, animationDelay: `${i * 0.35}s` }} />
          ))}
        </div>
        <p className="mt-3 text-center text-[11px] text-mute">Illustrative concept only — not real campaign data</p>
      </div>

      <div className="absolute -left-4 top-24 hidden animate-float rounded-xl border border-line bg-panel/95 p-3 text-xs shadow-xl sm:block" aria-hidden="true">
        <p className="mb-2 font-semibold">Creative test</p>
        <div className="flex gap-2"><span className="h-8 w-6 rounded bg-electric/60" /><span className="h-8 w-6 rounded bg-violet/60" /></div>
      </div>
      <div className="absolute -right-3 bottom-12 hidden animate-float rounded-xl border border-line bg-panel/95 p-3 text-xs shadow-xl [animation-delay:1.5s] sm:block" aria-hidden="true">
        <p className="flex items-center gap-2 font-semibold"><span className="h-2 w-2 animate-pulseDot rounded-full bg-emerald-400" />Lead captured</p>
        <p className="mt-1 text-mute">Form submission</p>
      </div>
    </div>
  );
}
