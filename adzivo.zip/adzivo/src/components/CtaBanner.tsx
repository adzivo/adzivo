import { ButtonLink } from "./Button";
import { bookingHref } from "@/config/site";

export function CtaBanner({ title = "Ready to Make Your Marketing Work Harder?", cta = "Let’s Talk About Your Goals" }: { title?: string; cta?: string }) {
  return (
    <section className="py-16 sm:py-24">
      <div className="container-x">
        <div className="hero-glow relative overflow-hidden rounded-3xl border border-line bg-panel px-6 py-14 text-center sm:px-12 sm:py-20">
          <h2 className="mx-auto max-w-2xl text-3xl font-bold tracking-tight sm:text-4xl">{title}</h2>
          <p className="mx-auto mt-4 max-w-xl text-mute">Tell us about your business and goals. We will let you know honestly whether paid social is a good fit.</p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <ButtonLink href="/contact#contact-form">{cta}</ButtonLink>
            <ButtonLink href={bookingHref} variant="secondary">Book a Strategy Call</ButtonLink>
          </div>
        </div>
      </div>
    </section>
  );
}
