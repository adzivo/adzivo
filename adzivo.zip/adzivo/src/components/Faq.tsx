import { faqs } from "@/content/data";

export function Faq() {
  return (
    <div className="mx-auto max-w-3xl divide-y divide-line rounded-2xl border border-line bg-panel/60">
      {faqs.map((f) => (
        <details key={f.q} className="group px-5 sm:px-7">
          <summary className="flex cursor-pointer items-center justify-between gap-4 py-5 text-left font-semibold">
            {f.q}
            <span className="faq-icon flex-none text-2xl leading-none text-[#8fa6ff] transition-transform" aria-hidden="true">+</span>
          </summary>
          <p className="pb-6 text-mute">{f.a}</p>
        </details>
      ))}
    </div>
  );
}
