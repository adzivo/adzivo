import Link from "next/link";

export function LogoMark({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3b6bff" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="14" fill="#0e1630" stroke="rgba(148,163,209,0.3)" />
      <path d="M14 48 32 14l18 34h-9l-9-18-9 18z" fill="url(#lg)" />
    </svg>
  );
}

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2.5" aria-label="ADZIVO home">
      <LogoMark />
      <span className="text-lg font-bold tracking-[0.14em]">ADZIVO</span>
    </Link>
  );
}
