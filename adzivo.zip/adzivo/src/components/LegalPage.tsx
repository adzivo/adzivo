import type { ReactNode } from "react";
import { PageHero } from "./Section";

export function LegalPage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <>
      <PageHero eyebrow="Legal" title={title} intro="Last updated: [insert date before publishing]" />
      <div className="container-x max-w-3xl py-12 sm:py-16">
        <div role="note" className="mb-10 rounded-xl border border-amber-400/60 bg-amber-400/10 p-4 text-sm text-amber-100">
          <strong>Template — review before publication.</strong> This document is a starting point only and is not legal advice. Have it reviewed by a qualified lawyer and complete every [bracketed] item before publishing.
        </div>
        <div className="space-y-4 text-mute [&_h2]:mb-2 [&_h2]:mt-10 [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:text-white [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-6">{children}</div>
      </div>
    </>
  );
}
