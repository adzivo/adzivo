"use client";

import { useRef, useState, type FormEvent } from "react";
import { BUDGETS, SERVICE_OPTIONS, validateContact, type FieldErrors } from "@/lib/validation";
import Link from "next/link";
import { site } from "@/config/site";

type Status = "idle" | "loading" | "success" | "error" | "not_configured";

export function ContactForm({ initialServices = [] }: { initialServices?: string[] }) {
  const [errors, setErrors] = useState<FieldErrors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");
  const [selected, setSelected] = useState<string[]>(initialServices);
  const startedAt = useRef(Date.now());
  const errorSummary = useRef<HTMLDivElement>(null);

  const toggle = (s: string) => setSelected((p) => (p.includes(s) ? p.filter((x) => x !== s) : [...p, s]));

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const payload = {
      name: fd.get("name"), email: fd.get("email"), company: fd.get("company"), budget: fd.get("budget"),
      services: selected, message: fd.get("message"), consent: fd.get("consent") === "on",
      website_url: fd.get("website_url"), startedAt: startedAt.current,
    };
    const { errors: clientErrors } = validateContact(payload);
    setErrors(clientErrors);
    if (Object.keys(clientErrors).length) {
      setStatus("idle");
      setTimeout(() => errorSummary.current?.focus(), 0);
      return;
    }
    setStatus("loading");
    setMessage("");
    try {
      const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const body = await res.json().catch(() => ({}));
      if (res.ok && body.ok) {
        setStatus("success");
        form.reset();
        setSelected([]);
      } else if (res.status === 422 && body.errors) {
        setErrors(body.errors);
        setStatus("idle");
      } else if (body.error === "not_configured") {
        setStatus("not_configured");
      } else {
        setStatus("error");
        setMessage(body.message || "Something went wrong. Please try again.");
      }
    } catch {
      setStatus("error");
      setMessage("Network error. Please check your connection and try again.");
    }
  }

  if (status === "success") {
    return (
      <div className="card text-center" role="status">
        <h2 className="text-2xl font-bold">Thank you — your message was sent.</h2>
        <p className="mt-3 text-mute">We will review your details and reply to your email address.</p>
        <button type="button" className="btn btn-secondary mt-6" onClick={() => { setStatus("idle"); startedAt.current = Date.now(); }}>Send another message</button>
      </div>
    );
  }

  const errList = Object.entries(errors);
  const fieldCls = (k: keyof FieldErrors) => `field ${errors[k] ? "field-error" : ""}`;
  const err = (k: keyof FieldErrors) => errors[k] && <p id={`${k}-error`} className="mt-1.5 text-sm text-red-300">{errors[k]}</p>;
  const aria = (k: keyof FieldErrors) => ({ "aria-invalid": errors[k] ? true : undefined, "aria-describedby": errors[k] ? `${k}-error` : undefined });

  return (
    <form id="contact-form" onSubmit={onSubmit} noValidate className="card space-y-5" aria-busy={status === "loading"}>
      {errList.length > 0 && (
        <div ref={errorSummary} tabIndex={-1} role="alert" className="rounded-lg border border-red-400/60 bg-red-500/10 p-4 text-sm">
          <p className="font-semibold">Please fix the following:</p>
          <ul className="mt-1 list-disc pl-5 text-red-200">{errList.map(([k, v]) => <li key={k}>{v}</li>)}</ul>
        </div>
      )}
      {status === "not_configured" && (
        <div role="alert" className="rounded-lg border border-amber-400/60 bg-amber-500/10 p-4 text-sm">
          <p className="font-semibold">The contact form isn’t set up yet.</p>
          <p className="mt-1 text-amber-100">Your message was <strong>not</strong> sent.{site.contact.email ? <> Please email us at <a className="underline" href={`mailto:${site.contact.email}`}>{site.contact.email}</a>.</> : " Please check back soon."}</p>
        </div>
      )}
      {status === "error" && <div role="alert" className="rounded-lg border border-red-400/60 bg-red-500/10 p-4 text-sm text-red-100">{message}</div>}

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="mb-1.5 block text-sm font-medium">Full name</label>
          <input id="name" name="name" autoComplete="name" className={fieldCls("name")} {...aria("name")} />
          {err("name")}
        </div>
        <div>
          <label htmlFor="email" className="mb-1.5 block text-sm font-medium">Business email</label>
          <input id="email" name="email" type="email" autoComplete="email" className={fieldCls("email")} {...aria("email")} />
          {err("email")}
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="company" className="mb-1.5 block text-sm font-medium">Company or website</label>
          <input id="company" name="company" autoComplete="organization" className={fieldCls("company")} {...aria("company")} />
          {err("company")}
        </div>
        <div>
          <label htmlFor="budget" className="mb-1.5 block text-sm font-medium">Monthly advertising budget</label>
          <select id="budget" name="budget" defaultValue="" className={fieldCls("budget")} {...aria("budget")}>
            <option value="" disabled>Select a range</option>
            {BUDGETS.map((b) => <option key={b} value={b}>{b}</option>)}
          </select>
          {err("budget")}
        </div>
      </div>

      <fieldset {...aria("services")}>
        <legend className="mb-2 text-sm font-medium">Services required</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {SERVICE_OPTIONS.map((s, i) => (
            <label key={s} htmlFor={`svc-${i}`} className="flex cursor-pointer items-center gap-3 rounded-lg border border-line bg-navy px-3 py-2.5 text-sm">
              <input id={`svc-${i}`} type="checkbox" checked={selected.includes(s)} onChange={() => toggle(s)} className="h-4 w-4 accent-electric" />
              {s}
            </label>
          ))}
        </div>
        {err("services")}
      </fieldset>

      <div>
        <label htmlFor="message" className="mb-1.5 block text-sm font-medium">Message</label>
        <textarea id="message" name="message" rows={5} placeholder="Tell us about your business and what you want to achieve." className={fieldCls("message")} {...aria("message")} />
        {err("message")}
      </div>

      {/* Honeypot — hidden from humans and assistive tech */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor="website_url">Leave this field empty</label>
        <input id="website_url" name="website_url" tabIndex={-1} autoComplete="off" />
      </div>

      <div>
        <label htmlFor="consent" className="flex cursor-pointer items-start gap-3 text-sm text-mute">
          <input id="consent" name="consent" type="checkbox" className="mt-0.5 h-4 w-4 accent-electric" {...aria("consent")} />
          <span>I agree to ADZIVO processing my details to respond to this enquiry, as described in the <Link href="/privacy" className="underline hover:text-white">Privacy Policy</Link>.</span>
        </label>
        {err("consent")}
      </div>

      <button type="submit" disabled={status === "loading"} className="btn btn-primary w-full disabled:cursor-not-allowed disabled:opacity-60">
        {status === "loading" ? "Sending…" : "Send Message"}
      </button>
    </form>
  );
}
