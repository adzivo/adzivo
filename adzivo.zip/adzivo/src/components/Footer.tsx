import Link from "next/link";
import { site, nav } from "@/config/site";
import { services } from "@/content/data";
import { Logo } from "./Logo";

export function Footer() {
  const { email, phone, address } = site.contact;
  const hasContact = email || phone || address;
  return (
    <footer className="border-t border-line bg-navy/60">
      <div className="container-x grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm text-mute">{site.description}</p>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Services</h2>
          <ul className="mt-4 space-y-2 text-sm text-mute">
            {services.map((s) => (
              <li key={s.slug}><Link className="hover:text-white" href={`/services#${s.slug}`}>{s.title}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Company</h2>
          <ul className="mt-4 space-y-2 text-sm text-mute">
            {nav.map((n) => (<li key={n.href}><Link className="hover:text-white" href={n.href}>{n.label}</Link></li>))}
            <li><Link className="hover:text-white" href="/privacy">Privacy Policy</Link></li>
            <li><Link className="hover:text-white" href="/terms">Terms of Service</Link></li>
          </ul>
        </div>
        <div>
          <h2 className="text-sm font-semibold">Contact</h2>
          <ul className="mt-4 space-y-2 text-sm text-mute">
            {email && <li><a className="hover:text-white" href={`mailto:${email}`}>{email}</a></li>}
            {phone && <li><a className="hover:text-white" href={`tel:${phone.replace(/[^+\d]/g, "")}`}>{phone}</a></li>}
            {address && <li>{address}</li>}
            {!hasContact && <li><Link className="hover:text-white" href="/contact">Send us a message</Link></li>}
            {site.social.map((s) => (
              <li key={s.href}><a className="hover:text-white" href={s.href} target="_blank" rel="noopener noreferrer">{s.label}</a></li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t border-line">
        <div className="container-x flex flex-col gap-2 py-6 text-xs text-mute sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} {site.name}. All rights reserved.</p>
          <p>ADZIVO is an independent agency and is not affiliated with or endorsed by Meta Platforms, Inc.</p>
        </div>
      </div>
    </footer>
  );
}
