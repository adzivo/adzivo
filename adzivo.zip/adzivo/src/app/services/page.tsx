import { pageMetadata } from "@/lib/metadata";
import { services } from "@/content/data";
import { PageHero, Section } from "@/components/Section";
import { ServiceIcon, Check } from "@/components/Icons";
import { ButtonLink } from "@/components/Button";
import { CtaBanner } from "@/components/CtaBanner";

export const metadata = pageMetadata({
  title: "Paid Social Advertising Services",
  description: "Meta Ads management, Facebook and Instagram campaigns, creative testing, lead generation, retargeting and analytics from ADZIVO.",
  path: "/services",
});

export default function ServicesPage() {
  return (
    <>
      <PageHero eyebrow="Services" title="Paid social services built around your goals" intro="Choose a single service or combine them. Every engagement starts with understanding your offer, audience and economics." />

      <Section className="!pb-8">
        <div className="card border-electric/40">
          <h2 className="text-xl font-semibold">Management fees vs. advertising spend</h2>
          <p className="mt-2 text-mute">
            ADZIVO’s fees cover strategy, setup, management and reporting. Advertising spend is a separate budget paid directly to the advertising platform from your own ad account. We do not guarantee sales, leads or return on ad spend; results depend on many factors, including your offer, market, creative and budget.
          </p>
        </div>
      </Section>

      {services.map((s, idx) => (
        <section key={s.slug} id={s.slug} className={`py-14 sm:py-20 ${idx % 2 ? "bg-navy/40" : ""}`}>
          <div className="container-x grid gap-10 lg:grid-cols-[1fr_1.2fr]">
            <div>
              <ServiceIcon name={s.icon} />
              <h2 className="mt-5 text-3xl font-bold tracking-tight">{s.title}</h2>
              <p className="mt-4 text-mute">{s.description}</p>
              <div className="card mt-6">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-[#8fa6ff]">Ideal client</h3>
                <p className="mt-2 text-mute">{s.idealClient}</p>
              </div>
              <div className="mt-6"><ButtonLink href={`/contact?service=${s.slug}#contact-form`}>Discuss {s.title}</ButtonLink></div>
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <div className="card">
                <h3 className="font-semibold">Deliverables</h3>
                <ul className="mt-3 space-y-2 text-sm text-mute">{s.deliverables.map((d) => <li key={d} className="flex gap-2"><Check />{d}</li>)}</ul>
              </div>
              <div className="card">
                <h3 className="font-semibold">Process</h3>
                <ol className="mt-3 space-y-2 text-sm text-mute">
                  {s.process.map((p, i) => <li key={p} className="flex gap-3"><span className="font-semibold text-[#8fa6ff]">{i + 1}.</span>{p}</li>)}
                </ol>
              </div>
            </div>
          </div>
        </section>
      ))}
      <CtaBanner />
    </>
  );
}
