import { pageMetadata } from "@/lib/metadata";
import { site, bookingHref } from "@/config/site";
import { services } from "@/content/data";
import { PageHero, Section } from "@/components/Section";
import { ContactForm } from "@/components/ContactForm";
import { ButtonLink } from "@/components/Button";

export const metadata = pageMetadata({
  title: "Contact",
  description: "Book a strategy call or send ADZIVO a message about your paid social advertising goals.",
  path: "/contact",
});

export default function ContactPage({ searchParams }: { searchParams: { service?: string } }) {
  const preselected = services.filter((s) => s.slug === searchParams.service).map((s) => s.title);
  const { email, phone, address } = site.contact;
  return (
    <>
      <PageHero eyebrow="Contact" title="Let’s talk about your goals" intro="Tell us about your business and what you want to achieve. We will reply and let you know honestly whether we’re a good fit." />
      <Section>
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr]">
          <ContactForm initialServices={preselected} />
          <aside className="space-y-5">
            <div className="card">
              <h2 className="text-lg font-semibold">Prefer to talk live?</h2>
              <p className="mt-2 text-mute">Pick a time that suits you for a strategy call.</p>
              <div className="mt-5"><ButtonLink href={bookingHref}>Book a Strategy Call</ButtonLink></div>
            </div>
            {(email || phone || address) && (
              <div className="card text-sm">
                <h2 className="text-lg font-semibold">Contact details</h2>
                <ul className="mt-3 space-y-2 text-mute">
                  {email && <li><a className="underline hover:text-white" href={`mailto:${email}`}>{email}</a></li>}
                  {phone && <li><a className="underline hover:text-white" href={`tel:${phone.replace(/[^+\d]/g, "")}`}>{phone}</a></li>}
                  {address && <li>{address}</li>}
                </ul>
              </div>
            )}
            <div className="card text-sm text-mute">
              <h2 className="text-lg font-semibold text-white">What happens next</h2>
              <ol className="mt-3 list-decimal space-y-2 pl-5">
                <li>We review your message.</li>
                <li>We reply to discuss goals and fit.</li>
                <li>If it makes sense, we outline a recommended approach.</li>
              </ol>
            </div>
          </aside>
        </div>
      </Section>
    </>
  );
}
