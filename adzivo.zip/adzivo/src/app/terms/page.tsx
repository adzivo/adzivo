import { pageMetadata } from "@/lib/metadata";
import { site } from "@/config/site";
import { LegalPage } from "@/components/LegalPage";

export const metadata = pageMetadata({ title: "Terms of Service", description: "Terms governing use of the ADZIVO website and services.", path: "/terms" });

export default function TermsPage() {
  return (
    <LegalPage title="Terms of Service">
      <p>These terms govern your use of the {site.name} website. Services are provided under a separate written agreement. Legal entity name and jurisdiction: [insert].</p>
      <h2>Use of the website</h2>
      <p>You agree to use the site lawfully and not to attempt to disrupt it, submit spam or misuse the contact form.</p>
      <h2>No guarantee of results</h2>
      <p>Information on this website is general. Advertising outcomes depend on many factors outside our control, and we do not guarantee sales, leads, return on ad spend or any specific result.</p>
      <h2>Fees and advertising spend</h2>
      <p>Management fees are separate from advertising spend. Advertising spend is paid directly to the advertising platform from the client’s own account. [Insert fee, billing and cancellation terms in the service agreement.]</p>
      <h2>Third-party platforms</h2>
      <p>{site.name} is an independent agency and is not affiliated with or endorsed by Meta Platforms, Inc. Platform names are used only to describe the services we provide. Use of third-party platforms is subject to their own terms.</p>
      <h2>Intellectual property</h2>
      <p>Website content is owned by {site.name} or its licensors. Ownership of campaign assets is set out in the service agreement: [insert].</p>
      <h2>Limitation of liability</h2>
      <p>[Insert limitation of liability and disclaimer language approved by counsel.]</p>
      <h2>Changes and governing law</h2>
      <p>We may update these terms from time to time. Governing law and venue: [insert].</p>
    </LegalPage>
  );
}
