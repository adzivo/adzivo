import { pageMetadata } from "@/lib/metadata";
import { site } from "@/config/site";
import { reasons } from "@/content/data";
import { PageHero, Section } from "@/components/Section";
import { CtaBanner } from "@/components/CtaBanner";

export const metadata = pageMetadata({
  title: "About Us",
  description: "ADZIVO is a performance-focused paid social agency built on strategy, testing and transparent reporting.",
  path: "/about",
});

export default function AboutPage() {
  return (
    <>
      <PageHero eyebrow="About ADZIVO" title="A performance-focused paid social agency" intro="We help businesses turn advertising budgets into qualified leads and customers through careful strategy, structured testing and honest reporting." />
      <Section>
        <div className="grid gap-5 md:grid-cols-2">
          <div className="card"><h2 className="text-xl font-semibold">Our mission</h2><p className="mt-3 text-mute">To help ambitious businesses grow by making paid social advertising clearer, more accountable and tied to real business goals.</p></div>
          <div className="card"><h2 className="text-xl font-semibold">How we work</h2><p className="mt-3 text-mute">We start with your offer and economics, build a plan we can measure, test deliberately and share what we learn, including what doesn’t work.</p></div>
        </div>
      </Section>
      <Section eyebrow="Our philosophy" title="What guides our work" className="bg-navy/40">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {reasons.map((r) => (<div key={r.title} className="card"><h3 className="font-semibold">{r.title}</h3><p className="mt-2 text-mute">{r.text}</p></div>))}
        </div>
      </Section>
      {site.history && <Section eyebrow="Our story" title="Company history"><p className="max-w-3xl text-mute">{site.history}</p></Section>}
      {site.team.length > 0 && (
        <Section eyebrow="Team" title="The people behind ADZIVO">
          <div className="grid gap-5 md:grid-cols-3">
            {site.team.map((m) => (<div key={m.name} className="card"><h3 className="font-semibold">{m.name}</h3><p className="text-sm text-[#8fa6ff]">{m.role}</p><p className="mt-3 text-sm text-mute">{m.bio}</p></div>))}
          </div>
        </Section>
      )}
      {site.credentials.length > 0 && (
        <Section eyebrow="Credentials" title="Certifications and recognition">
          <ul className="grid gap-3 sm:grid-cols-2">{site.credentials.map((c) => <li key={c} className="card">{c}</li>)}</ul>
        </Section>
      )}
      <CtaBanner />
    </>
  );
}
