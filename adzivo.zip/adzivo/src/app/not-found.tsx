import type { Metadata } from "next";
import { ButtonLink } from "@/components/Button";

export const metadata: Metadata = { title: "Page not found", robots: { index: false } };

export default function NotFound() {
  return (
    <section className="hero-glow flex min-h-[80vh] items-center pt-16">
      <div className="container-x text-center">
        <p className="gradient-text text-7xl font-bold">404</p>
        <h1 className="mt-4 text-3xl font-bold">This page doesn’t exist</h1>
        <p className="mx-auto mt-3 max-w-md text-mute">The link may be broken or the page may have moved. Let’s get you back on track.</p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <ButtonLink href="/">Back to Home</ButtonLink>
          <ButtonLink href="/contact" variant="secondary">Contact Us</ButtonLink>
        </div>
      </div>
    </section>
  );
}
