import { ImageResponse } from "next/og";

export const alt = "ADZIVO — Turn Ad Spend Into Scalable Growth.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OgImage() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", padding: 80, background: "linear-gradient(135deg,#04060d 40%,#1a1f5c)", color: "white", fontFamily: "sans-serif" }}>
        <div style={{ fontSize: 34, letterSpacing: 10, fontWeight: 700, color: "#8fa6ff" }}>ADZIVO</div>
        <div style={{ fontSize: 76, fontWeight: 800, marginTop: 28, lineHeight: 1.1 }}>Turn Ad Spend Into Scalable Growth.</div>
        <div style={{ fontSize: 30, marginTop: 28, color: "#a9b4d0" }}>Performance marketing built around your business goals.</div>
      </div>
    ),
    size
  );
}
