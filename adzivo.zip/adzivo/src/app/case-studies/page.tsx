import { pageMetadata } from "@/lib/metadata";
import { caseStudies } from "@/content/data";
import { PageHero, Section } from "@/components/Section";
import { CaseStudyCard } from "@/components/CaseStudyCard";
import { CtaBanner } from "@/components/CtaBanner";

export const metadata = pageMetadata({
  title: "Case Studies",
  description: "See how ADZIVO will present client campaign results: challenge, strategy, timeframe and verified outcomes.",
  path: "/case-studies",
});

export default function CaseStudiesPage() {
  return (
    <>
      <PageHero eyebrow="Case studies" title="Results, shown transparently" intro="Real case studies will be published here once clients have approved them. Each one covers the challenge, strategy, timeframe and verified results." />
      <Section>
        <div className="mb-8 rounded-xl border border-amber-400/60 bg-amber-400/10 p-4 text-sm text-amber-100" role="note">
          <strong>Demo layout.</strong> The entries below are templates, not real client work. Edit <code className="rounded bg-black/30 px-1">src/content/data.ts</code> to add verified case studies, then remove the demo label.
        </div>
        <div className="grid gap-5 lg:grid-cols-3">{caseStudies.map((c, i) => <CaseStudyCard key={i} study={c} />)}</div>
      </Section>
      <CtaBanner />
    </>
  );
}
