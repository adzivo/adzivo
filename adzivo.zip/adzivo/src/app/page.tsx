import Link from "next/link";
import { site, bookingHref } from "@/config/site";
import { services, processSteps, industries, reasons, caseStudies, testimonials } from "@/content/data";
import { ButtonLink } from "@/components/Button";
import { Section } from "@/components/Section";
import { ServiceIcon } from "@/components/Icons";
import { HeroVisual } from "@/components/HeroVisual";
import { Faq } from "@/components/Faq";
import { CtaBanner } from "@/components/CtaBanner";
import { CaseStudyCard } from "@/components/CaseStudyCard";

export default function HomePage() {
  return (
    <>
      <section className="hero-glow relative overflow-hidden pb-20 pt-32 sm:pb-28 sm:pt-40">
        <div className="grid-bg absolute inset-0" aria-hidden="true" />
        <div className="container-x relative grid items-center gap-14 lg:grid-cols-2">
          <div>
            <p className="eyebrow mb-5">Performance Marketing Agency</p>
            <h1 className="text-4xl font-bold leading-[1.08] tracking-tight sm:text-6xl">
              Turn Ad Spend Into <span className="gradient-text">Scalable Growth.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-mute">
              We help ambitious businesses build smarter paid social campaigns, generate qualified leads, and make better decisions with performance-focused advertising.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <ButtonLink href={bookingHref}>Book a Strategy Call</ButtonLink>
              <ButtonLink href="/services" variant="secondary">Explore Our Services</ButtonLink>
            </div>
            <p className="mt-6 text-sm text-mute">{site.supporting}</p>
          </div>
          <HeroVisual />
        </div>
      </section>

      <Section eyebrow="What you can expect" title="A focused partner for paid social" intro="We don’t list client logos we can’t verify. Here is what you can expect when you work with us.">
        <div className="grid gap-5 md:grid-cols-3">
          {[
            ["Goal-led strategy", "Campaigns are planned around your offer, margins and what a good customer is worth to you."],
            ["Honest expectations", "We never promise specific sales, leads or return on ad spend. We commit to process, testing and transparency."],
            ["You own your accounts", "Your ad accounts, data and spend stay yours. We work inside them on your behalf."],
          ].map(([t, d]) => (
            <div key={t} className="card"><h3 className="text-lg font-semibold">{t}</h3><p className="mt-2 text-mute">{d}</p></div>
          ))}
        </div>
      </Section>

      <Section id="services" eyebrow="Services" title="Everything you need to run paid social well" className="bg-navy/40">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <Link key={s.slug} href={`/services#${s.slug}`} className="card card-hover group block">
              <ServiceIcon name={s.icon} />
              <h3 className="mt-5 text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-mute">{s.summary}</p>
              <span className="mt-5 inline-block text-sm font-semibold text-[#8fa6ff] group-hover:text-white">Learn more →</span>
            </Link>
          ))}
        </div>
      </Section>

      <Section eyebrow="Case studies" title="How we present results" intro="Case studies will appear here once client work has been approved for publication. The layout below shows what each one will include.">
        <div className="grid gap-5 lg:grid-cols-3">
          {caseStudies.map((c, i) => <CaseStudyCard key={i} study={c} />)}
        </div>
        <div className="mt-8"><ButtonLink href="/case-studies" variant="secondary">View case study layout</ButtonLink></div>
      </Section>

      <Section eyebrow="Our process" title="From first call to scale" className="bg-navy/40">
        <ol className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {processSteps.map((p) => (
            <li key={p.n} className="card">
              <span className="gradient-text text-3xl font-bold">{p.n}</span>
              <h3 className="mt-3 text-lg font-semibold">{p.title}</h3>
              <p className="mt-2 text-mute">{p.text}</p>
            </li>
          ))}
        </ol>
      </Section>

      <Section eyebrow="Who we help" title="Built for businesses that grow through enquiries and customers">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {industries.map((i) => (
            <div key={i.title} className="card"><h3 className="font-semibold">{i.title}</h3><p className="mt-2 text-sm text-mute">{i.text}</p></div>
          ))}
        </div>
      </Section>

      <Section eyebrow="Why ADZIVO" title="Clear thinking, clear reporting" className="bg-navy/40">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {reasons.map((r) => (
            <div key={r.title} className="card"><h3 className="font-semibold">{r.title}</h3><p className="mt-2 text-mute">{r.text}</p></div>
          ))}
        </div>
      </Section>

      {testimonials.length > 0 ? (
        <Section eyebrow="Testimonials" title="What clients say">
          <div className="grid gap-5 md:grid-cols-2">
            {testimonials.map((t) => (
              <figure key={t.name} className="card">
                <blockquote className="text-lg">“{t.quote}”</blockquote>
                <figcaption className="mt-4 text-sm text-mute">{t.name}, {t.role}, {t.company}</figcaption>
              </figure>
            ))}
          </div>
        </Section>
      ) : (
        <Section eyebrow="Our approach" title="How we work with you">
          <div className="grid gap-5 md:grid-cols-3">
            {[
              ["Test, don’t guess", "We form hypotheses, run structured tests and keep only what the data supports."],
              ["Report in plain language", "Updates explain what changed, why it matters and what we will do next."],
              ["Optimize for your business", "We focus on the outcomes you care about rather than platform vanity metrics."],
            ].map(([t, d]) => (
              <div key={t} className="card"><h3 className="font-semibold">{t}</h3><p className="mt-2 text-mute">{d}</p></div>
            ))}
          </div>
        </Section>
      )}

      <Section eyebrow="FAQ" title="Frequently asked questions"><Faq /></Section>
      <CtaBanner />
    </>
  );
}
