import { NextResponse } from "next/server";
import { validateContact } from "@/lib/validation";
import { rateLimit } from "@/lib/rateLimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
const json = (body: Record<string, unknown>, status: number, headers?: Record<string, string>) =>
  NextResponse.json(body, { status, headers });

export async function POST(req: Request) {
  // Same-origin check (blocks cross-site form posts)
  const origin = req.headers.get("origin");
  const host = req.headers.get("host");
  if (origin && host && new URL(origin).host !== host) return json({ error: "forbidden" }, 403);

  const ip = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || "unknown";
  const rl = rateLimit(ip);
  if (!rl.ok) return json({ error: "rate_limited", message: "Too many requests. Please try again later." }, 429, { "Retry-After": String(rl.retryAfter) });

  const len = Number(req.headers.get("content-length") || 0);
  if (len > 20_000) return json({ error: "too_large", message: "Request too large." }, 413);

  let raw: Record<string, unknown>;
  try {
    raw = await req.json();
  } catch {
    return json({ error: "invalid_json", message: "Invalid request." }, 400);
  }

  // Honeypot: bots fill hidden fields. Respond neutrally and discard.
  if (typeof raw.website_url === "string" && raw.website_url.trim() !== "") return json({ ok: true }, 200);
  // Timing check: humans take more than 3 seconds to complete the form.
  const startedAt = Number(raw.startedAt);
  if (!Number.isFinite(startedAt) || Date.now() - startedAt < 3000) {
    return json({ error: "too_fast", message: "Please take a moment to complete the form and try again." }, 400);
  }

  const { errors, data } = validateContact(raw);
  if (Object.keys(errors).length) return json({ error: "validation", errors }, 422);

  const resendKey = process.env.RESEND_API_KEY;
  const to = process.env.CONTACT_TO_EMAIL;
  const from = process.env.CONTACT_FROM_EMAIL;
  const webhook = process.env.CONTACT_WEBHOOK_URL;
  const emailReady = Boolean(resendKey && to && from);

  // Never report success when nothing is configured to receive the lead.
  if (!emailReady && !webhook) {
    console.error("[contact] No delivery method configured. Set RESEND_API_KEY/CONTACT_TO_EMAIL/CONTACT_FROM_EMAIL or CONTACT_WEBHOOK_URL.");
    return json({ error: "not_configured", message: "The contact form is not configured yet." }, 503);
  }

  const text = [
    `Name: ${data.name}`, `Email: ${data.email}`, `Company/Website: ${data.company}`,
    `Monthly ad budget: ${data.budget}`, `Services: ${data.services.join(", ")}`, "", data.message,
  ].join("\n");
  const html = `<h2>New ADZIVO enquiry</h2><table cellpadding="6">
    <tr><td><b>Name</b></td><td>${esc(data.name)}</td></tr>
    <tr><td><b>Email</b></td><td>${esc(data.email)}</td></tr>
    <tr><td><b>Company/Website</b></td><td>${esc(data.company)}</td></tr>
    <tr><td><b>Budget</b></td><td>${esc(data.budget)}</td></tr>
    <tr><td><b>Services</b></td><td>${esc(data.services.join(", "))}</td></tr></table>
    <p style="white-space:pre-wrap">${esc(data.message)}</p>`;

  try {
    if (emailReady) {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from, to: [to], reply_to: data.email, subject: `New enquiry from ${data.name}`, html, text }),
      });
      if (!r.ok) throw new Error(`Resend responded ${r.status}`);
    }
    if (webhook) {
      const r = await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, submittedAt: new Date().toISOString(), source: "adzivo-website" }),
      });
      if (!r.ok) throw new Error(`Webhook responded ${r.status}`);
    }
    return json({ ok: true }, 200);
  } catch (err) {
    console.error("[contact] delivery failed:", err);
    return json({ error: "delivery_failed", message: "We couldn’t send your message. Please try again shortly." }, 502);
  }
}

export function GET() {
  return json({ error: "method_not_allowed" }, 405, { Allow: "POST" });
}
