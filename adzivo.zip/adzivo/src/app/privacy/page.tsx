import { pageMetadata } from "@/lib/metadata";
import { site } from "@/config/site";
import { LegalPage } from "@/components/LegalPage";

export const metadata = pageMetadata({ title: "Privacy Policy", description: "How ADZIVO collects, uses and protects personal information.", path: "/privacy" });

export default function PrivacyPage() {
  return (
    <LegalPage title="Privacy Policy">
      <p>This policy explains how {site.name} (“we”, “us”) handles personal information collected through this website. Legal entity name and registered details: [insert].</p>
      <h2>Information we collect</h2>
      <ul>
        <li>Details you submit through the contact form: name, business email, company or website, advertising budget range, services of interest and your message.</li>
        <li>Basic technical data such as IP address (used for spam prevention and rate limiting) and browser information.</li>
        <li>[Add any analytics, cookies or advertising pixels used on this site, or confirm none are used.]</li>
      </ul>
      <h2>How we use information</h2>
      <ul>
        <li>To respond to your enquiry and discuss our services.</li>
        <li>To prevent spam and abuse and to keep the website secure.</li>
        <li>To meet legal obligations.</li>
      </ul>
      <h2>Sharing</h2>
      <p>We do not sell personal information. We may share it with service providers that help us operate the site and handle enquiries (for example, email delivery or CRM providers: [list providers]).</p>
      <h2>Retention</h2>
      <p>We keep enquiry information only as long as needed for the purposes above: [insert retention period].</p>
      <h2>Your rights</h2>
      <p>Depending on where you live (including under laws such as the CCPA/CPRA in California), you may have rights to access, correct or delete your information. [Describe how to submit a request.]</p>
      <h2>Contact</h2>
      <p>{site.contact.email ? <>Questions about this policy: {site.contact.email}.</> : "[Insert privacy contact email.]"}</p>
    </LegalPage>
  );
}
