import { services } from "@/content/data";

export const BUDGETS = ["Under $1,000 / month", "$1,000 – $3,000 / month", "$3,000 – $10,000 / month", "$10,000+ / month", "Not sure yet"] as const;
export const SERVICE_OPTIONS = services.map((s) => s.title);

export type ContactInput = {
  name: string; email: string; company: string; budget: string; services: string[]; message: string; consent: boolean;
};
export type FieldErrors = Partial<Record<keyof ContactInput, string>>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const str = (v: unknown) => (typeof v === "string" ? v.trim() : "");

/** Shared by the browser and the API route so both enforce identical rules. */
export function validateContact(raw: Record<string, unknown>): { errors: FieldErrors; data: ContactInput } {
  const data: ContactInput = {
    name: str(raw.name),
    email: str(raw.email),
    company: str(raw.company),
    budget: str(raw.budget),
    services: Array.isArray(raw.services) ? raw.services.filter((s): s is string => typeof s === "string") : [],
    message: str(raw.message),
    consent: raw.consent === true,
  };
  const errors: FieldErrors = {};
  if (data.name.length < 2) errors.name = "Please enter your full name.";
  else if (data.name.length > 100) errors.name = "Name is too long.";
  if (!EMAIL_RE.test(data.email) || data.email.length > 200) errors.email = "Please enter a valid business email address.";
  if (data.company.length < 2) errors.company = "Please enter your company name or website.";
  else if (data.company.length > 200) errors.company = "That entry is too long.";
  if (!(BUDGETS as readonly string[]).includes(data.budget)) errors.budget = "Please choose a monthly ad budget range.";
  if (data.services.length === 0 || !data.services.every((s) => SERVICE_OPTIONS.includes(s))) errors.services = "Please select at least one service.";
  if (data.message.length < 10) errors.message = "Please tell us a little about your goals (at least 10 characters).";
  else if (data.message.length > 3000) errors.message = "Message must be under 3,000 characters.";
  if (!data.consent) errors.consent = "Please agree to the privacy policy so we can respond.";
  return { errors, data };
}
