/**
 * Central site settings. Edit values here or via environment variables (.env.local).
 * Anything left empty is simply hidden from the UI — nothing is invented.
 */
export const site = {
  name: "ADZIVO",
  url: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
  tagline: "Turn Ad Spend Into Scalable Growth.",
  supporting: "Performance marketing built around your business goals.",
  description:
    "ADZIVO is a performance marketing agency helping businesses generate qualified leads and customers through paid social advertising on Meta platforms.",
  contact: {
    email: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "",
    phone: process.env.NEXT_PUBLIC_CONTACT_PHONE || "",
    address: process.env.NEXT_PUBLIC_CONTACT_ADDRESS || "",
  },
  /** Scheduling link (Calendly, Cal.com…). Falls back to the contact form when empty. */
  bookingUrl: process.env.NEXT_PUBLIC_BOOKING_URL || "",
  /** Social profile URLs, e.g. { label: "LinkedIn", href: "https://…" } */
  social: [] as { label: string; href: string }[],
  /** Editable About-page content. Empty values hide their sections. */
  team: [] as { name: string; role: string; bio: string }[],
  credentials: [] as string[],
  history: "",
};

export const bookingHref = site.bookingUrl || "/contact#contact-form";

export const nav = [
  { label: "Home", href: "/" },
  { label: "Services", href: "/services" },
  { label: "Case Studies", href: "/case-studies" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];
