export type Service = {
  slug: string;
  title: string;
  icon: "target" | "social" | "flask" | "users" | "funnel" | "chart";
  summary: string;
  description: string;
  deliverables: string[];
  process: string[];
  idealClient: string;
};

export const services: Service[] = [
  {
    slug: "meta-ads-management",
    title: "Meta Ads Management",
    icon: "target",
    summary: "Ongoing management of your Meta advertising account, from structure and budgets to weekly optimization.",
    description:
      "We plan, launch and manage campaigns across Meta’s advertising platform with a clear structure, defined goals and consistent optimization. Decisions are tied to your business economics, not vanity metrics.",
    deliverables: ["Account and campaign structure", "Audience and budget strategy", "Weekly optimization and monitoring", "Regular performance reporting"],
    process: ["Audit goals, offer and current account", "Build structure and launch plan", "Monitor and optimize on a set cadence", "Review results and agree next steps"],
    idealClient: "Businesses with a clear offer that want a dedicated team running paid social day to day.",
  },
  {
    slug: "facebook-instagram-campaigns",
    title: "Facebook & Instagram Campaigns",
    icon: "social",
    summary: "Placement-aware campaigns designed for how people actually use Facebook and Instagram.",
    description:
      "Feed, Stories and Reels each reward different creative and messaging. We build campaigns that fit the placement and the stage of the buyer journey, from first impression to enquiry.",
    deliverables: ["Campaign plans by objective", "Placement and format strategy", "Ad copy and creative briefs", "Launch checklist and QA"],
    process: ["Map audiences to objectives", "Select placements and formats", "Produce copy and briefs", "Launch, review and refine"],
    idealClient: "Brands and service businesses that want a consistent presence and measurable enquiries on both platforms.",
  },
  {
    slug: "creative-strategy-testing",
    title: "Creative Strategy & Testing",
    icon: "flask",
    summary: "A structured approach to testing hooks, angles and formats so creative decisions are evidence-based.",
    description:
      "Creative is often the biggest lever in paid social. We define hypotheses, test them in an organized way and keep what works, so each round of creative teaches you something about your audience.",
    deliverables: ["Creative strategy and angles", "Testing roadmap and naming conventions", "Creative briefs and iteration plans", "Learnings summary after each test cycle"],
    process: ["Research audience and offer", "Define test hypotheses", "Run controlled tests", "Document learnings and iterate"],
    idealClient: "Teams that can produce or source creative and want a disciplined testing framework behind it.",
  },
  {
    slug: "lead-generation-campaigns",
    title: "Lead Generation Campaigns",
    icon: "users",
    summary: "Campaigns built to bring in enquiries and focus on lead quality, not just lead volume.",
    description:
      "We set up lead campaigns with on-platform forms or landing pages, qualification questions and follow-up considerations, so the leads you receive are worth talking to.",
    deliverables: ["Lead form or landing-page strategy", "Qualification questions", "Lead routing and CRM handoff recommendations", "Lead quality feedback loop"],
    process: ["Define what a qualified lead is", "Build the capture experience", "Launch and monitor lead quality", "Refine targeting and messaging"],
    idealClient: "Local, professional-services and B2B businesses that win customers through enquiries and calls.",
  },
  {
    slug: "retargeting-funnel-optimization",
    title: "Retargeting & Funnel Optimization",
    icon: "funnel",
    summary: "Reach people who already showed interest and remove friction between ad click and conversion.",
    description:
      "We design retargeting sequences and review the full path from ad to action, identifying where interested people drop off and what to test next.",
    deliverables: ["Retargeting audience plan", "Sequenced messaging", "Funnel and landing-page recommendations", "Conversion-path review"],
    process: ["Map the current funnel", "Segment warm audiences", "Launch retargeting sequences", "Test and improve the path to conversion"],
    idealClient: "Businesses already receiving traffic or leads that want to convert more of what they already earn.",
  },
  {
    slug: "tracking-analytics-reporting",
    title: "Tracking, Analytics & Reporting",
    icon: "chart",
    summary: "Reliable measurement and plain-language reporting so you know what is and isn’t working.",
    description:
      "Good decisions need good data. We plan tracking, check that events fire correctly and report in a format that connects ad performance to business outcomes, including its limitations.",
    deliverables: ["Tracking plan and event setup guidance", "Pixel and conversion API recommendations", "Reporting dashboard or recurring report", "Review calls with clear next actions"],
    process: ["Audit current tracking", "Plan events and goals", "Validate data quality", "Report and review on a regular schedule"],
    idealClient: "Any advertiser who wants transparent reporting and confidence in the numbers behind decisions.",
  },
];

export const processSteps = [
  { n: "01", title: "Discover", text: "Understand business goals, audience, offer, and economics." },
  { n: "02", title: "Strategize", text: "Build campaign strategy, creative direction, and tracking plans." },
  { n: "03", title: "Launch & Optimize", text: "Test, monitor, and improve campaigns." },
  { n: "04", title: "Scale", text: "Expand what works with transparent reporting." },
];

export const industries = [
  { title: "E-commerce", text: "Online stores looking to reach new customers and re-engage past visitors with paid social." },
  { title: "Local Services", text: "Service providers that want a steady flow of local enquiries and booked calls." },
  { title: "Professional Services", text: "Firms and consultants that need qualified enquiries from the right type of client." },
  { title: "B2B Companies", text: "Businesses with longer sales cycles that need lead generation and nurturing support." },
];

export const reasons = [
  { title: "Strategic thinking", text: "Every campaign starts with your goals, offer and unit economics." },
  { title: "Clear communication", text: "Plain-language updates, with no jargon-heavy reports." },
  { title: "Creative experimentation", text: "Structured testing that turns creative into learning." },
  { title: "Transparent reporting", text: "You see what we see, including what isn’t working yet." },
  { title: "Business-focused optimization", text: "We optimize toward outcomes that matter to your business, not just platform metrics." },
];

export const faqs = [
  { q: "What services does ADZIVO offer?", a: "We provide Meta Ads management, Facebook and Instagram campaigns, creative strategy and testing, lead generation, retargeting and funnel optimization, and tracking, analytics and reporting." },
  { q: "Which businesses are a good fit?", a: "Businesses with a clear offer, a defined customer, and the capacity to follow up on leads or fulfil orders. This includes e-commerce, local services, professional services and B2B companies. We will tell you honestly if paid social is not the right fit." },
  { q: "What is the minimum advertising budget?", a: "It depends on your market, offer and goals. We discuss budget during the consultation and will be upfront if a budget is too small to produce meaningful learnings. Our management fee is separate from your ad spend." },
  { q: "How do you measure campaign success?", a: "We agree on goals up front, such as cost per qualified lead or cost per acquisition, and report against them alongside platform metrics. We also explain the limits of attribution so numbers are interpreted fairly." },
  { q: "How long does it take to launch campaigns?", a: "Timing depends on how quickly we can complete tracking, creative and approvals. We will give you a specific timeline after the discovery stage. Results vary and cannot be guaranteed." },
  { q: "Do clients pay advertising spend directly to Meta?", a: "Yes. Ad spend is paid directly from your own ad account to the platform, so you keep full ownership and visibility. Our fees are separate and cover strategy, management and reporting." },
  { q: "Do you provide creative and landing-page support?", a: "We provide creative strategy, briefs and testing plans, plus landing-page recommendations. Scope for production or page builds is agreed during onboarding." },
  { q: "How can I book a consultation?", a: "Use the Book a Strategy Call button or send us a message through the contact form, and we will follow up to arrange a time." },
];

/** DEMO CONTENT — replace with real, approved client case studies before publishing. */
export type CaseStudy = {
  client: string; industry: string; challenge: string; strategy: string; timeframe: string; results: string[];
};
export const caseStudies: CaseStudy[] = [
  {
    client: "[Client name]", industry: "E-commerce",
    challenge: "[Describe the client’s challenge in one or two sentences.]",
    strategy: "[Summarize the campaign strategy, creative approach and tracking setup.]",
    timeframe: "[e.g. 90 days]", results: ["[Verified result 1]", "[Verified result 2]", "[Verified result 3]"],
  },
  {
    client: "[Client name]", industry: "Local Services",
    challenge: "[Describe the client’s challenge in one or two sentences.]",
    strategy: "[Summarize the campaign strategy, creative approach and tracking setup.]",
    timeframe: "[e.g. 60 days]", results: ["[Verified result 1]", "[Verified result 2]", "[Verified result 3]"],
  },
  {
    client: "[Client name]", industry: "B2B",
    challenge: "[Describe the client’s challenge in one or two sentences.]",
    strategy: "[Summarize the campaign strategy, creative approach and tracking setup.]",
    timeframe: "[e.g. 6 months]", results: ["[Verified result 1]", "[Verified result 2]", "[Verified result 3]"],
  },
];

/** Real testimonials only. While empty, the homepage shows "Our Approach" instead. */
export const testimonials: { quote: string; name: string; role: string; company: string }[] = [];
